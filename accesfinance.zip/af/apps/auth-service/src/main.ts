// main.ts - Auth Service
// ✅ Charge le .env AVANT tout le reste (les services lisent process.env dès leur construction)
import 'dotenv/config';
import { NestFactory } from '@nestjs/core';
import { Transport, MicroserviceOptions } from '@nestjs/microservices';
import { AuthServiceModule } from './auth-service.module';
import { Logger } from '@nestjs/common';
import { RequestContextInterceptor } from '../../../libs/common/src/context/request-context.interceptor';
import { ensureTrackingColumns } from '../../../libs/common/src/audit/write-audit';
import { getSharedPrisma } from '../../../libs/common/src/db/shared-prisma';

async function bootstrap() {
  const app = await NestFactory.createMicroservice<MicroserviceOptions>(
    AuthServiceModule,
    {
      transport: Transport.RMQ,
      options: {
        urls: [process.env.RABBITMQ_URL || 'amqp://localhost:5672'],
        queue: 'auth_queue',  // ← Doit correspondre à AUTH_QUEUE dans .env
        queueOptions: {
          durable: false,
        },
        persistent: true,
        noAck: true,
        prefetchCount: 1,
      },
    },
  );

  const logger = new Logger('AuthService');

  // ✅ Contexte de la requête (IP, appareil, plateforme) transmis par l'API Gateway
  app.useGlobalInterceptors(new RequestContextInterceptor());
  // ✅ Colonnes de traçabilité (appareil / plateforme) présentes en base
  await ensureTrackingColumns(getSharedPrisma(), 'auth-service');

  await app.listen();
  logger.log('🔐 Auth microservice is running with RabbitMQ');
  logger.log(`📨 Queue: auth_queue`);
  logger.log(`🔗 RabbitMQ URL: ${process.env.RABBITMQ_URL || 'amqp://localhost:5672'}`);
}
bootstrap();